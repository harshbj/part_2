package com.example.admin.part_2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class Location extends AppCompatActivity {

    WebView location;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);
String url = "https://www.google.co.in/maps/place/Vidyavardhini's+College+of+Engineering+and+Technology/@19.3838696,72.8265449,17z/data=!3m1!4b1!4m5!3m4!1s0x3be7aec0a4b41bef:0xbd1a4ca919d6a613!8m2!3d19.3838696!4d72.8287336";


        location = (WebView)findViewById(R.id.location);
        location.getSettings().setJavaScriptEnabled(true);
        location.getSettings().setDomStorageEnabled(true);
        location.setOverScrollMode(location.OVER_SCROLL_NEVER);
        location.loadUrl(url);
        setTitle("Location");
    }



}
